/**
 * Direction:
 * Find missing number from the list
 *
 * Expected Result:
 * 8
 */
const numbers = [9, 6, 4, 2, 3, 5, 7, 0, 1];

function result(numbers) {
  // Your Code Here
  var numbers = ["9","6","4","2","3","5","7","0","1"];
  for (var i=1;i<numbers.length;i++){
      var thisI = parseInt(numbers[i].toLowerCase().split()[1]);
      var prevI = parseInt(numbers[i-1].toLowerCase().split()[1]);
      if (thisI != prevI+1)
        console.log(`Seems like ${prevI+1} is missing. thisI is ${thisI} and prevI is ${prevI}`)
  }
}

console.log(result(numbers));
