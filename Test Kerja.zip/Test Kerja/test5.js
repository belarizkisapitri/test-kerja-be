/**
 * Direction:
 * Find prefix of the word from array of string
 *
 * Expected Result:
 * fl
 */
const words = ['flower', 'flow', 'flight'];

function result(words) {
  // Your Code Here
  const words = words.map(e => {
    const split = e.split(' ');
    const amount = `${split[0]}`;
    
    return { val: e.replace(`${amount} `, ''), amount };
  });
}

console.log(result(words));
