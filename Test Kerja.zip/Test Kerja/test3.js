/**
 * Direction:
 * Remove key that have null or undefined value
 *
 * Expected Result:
 * [
 *   { session_name: 'first test', classes: [{ students: [{ student_name: 'budi' }] }] },
 *   { classes: [{ class_name: 'second class', students: [{ student_name: 'adi' }] }] },
 * ]
 */
const data = [
  { session_name: 'first test', classes: [{ class_name: undefined, students: [{ student_name: 'budi' }] }] },
  { session_name: null, classes: [{ class_name: 'second class', students: [{ student_name: 'adi' }] }] },
];

function result(data) {
  // Your Code Here
  if((predQuery.length < session_name) || (predQuery[session_name]=="") || (predQuery[session_name]=='undefined')){
    alert("its unbelievable");
    alert(predQuery[session_name]);
    queryPreds[variables] = session_name;
    queryObjs[variables] = objId;
    predQuery[session_name] = variables;
  }
  else {
    alert(predQuery[session_name]);
    var predIndex = predQuery[session_name];
    queryPreds[predIndex] = session_name;
    queryObjs[predIndex] = objId;
  }
}

console.log(result(data));
